var app = new Vue({
    el: '#app',
    data: {
        game_title: 'Mr. Manager',
        current_stage: 1,
        current_stage_title: "Stage 1",
        current_stage_body: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
        current_action_options: [
            {
                "action_category": "Brains",
                "action_body" : "You outsmart the inspector and they fail to find the mold infestation."
            },
            {
                "action_category": "Braun",
                "action_body" : "You choke out the inspector until he says he will never come back."
            },
            {
                "action_category": "Luck",
                "action_body" : "You challenge the inspector to a coin toss and win."
            },
            {
                "action_category": "GUILE",
                "action_body" : "You poison the inspector's drink and he dies."
            },
            {
                "action_category": "FERTILITY",
                "action_body" : "You have one of your sons take over the store while the inspector is working, giving you the ability to outsmart him at every turn. You have one of your sons take over the store while the inspector is working, giving you the ability to outsmart him at every turn."
            },
        ],
        player: {
            name: "Chunt",
            age: "45",
            job_title: "Manager",
            inventory: {
                bank: 250,
                items: [
                    {
                        name: "Elixir of Luck",
                        type: "statEffect",
                        uses: 1,
                        icon: "fa-"
                    }
                ],
                total_slots: 10
            },
            family: {
                family_size: 5,
                family_happiness: 5,
                wife_name: "Raven",
                wife_attractiveness: 8,
                wife_happiness: 7,
                wife_attitude: "rude",
            },
            stats: [
                {
                    stat_title: "Sex Appeal",
                    stat_value: 10
                },
                {
                    stat_title: "Brains",
                    stat_value: 9
                },
                {
                    stat_title: "Braun",
                    stat_value: 8
                },
                {
                    stat_title: "Humor",
                    stat_value: 7
                },
                {
                    stat_title: "Fertility",
                    stat_value: 6
                },
                {
                    stat_title: "Speech",
                    stat_value: 5
                },
                {
                    stat_title: "Luck",
                    stat_value: 6
                },
                {
                    stat_title: "Guile",
                    stat_value: 7
                }
            ]
                
            
        }
    }
  })