$(window).on("load", function() {


    

    var scroll = 0;

    $(".app--container").scroll(function() {
         scroll = $(".app--container").scrollTop(); 
         console.log("Scroll: "+scroll);
     })
    
    
    var page = 'mockstarket';

    if(page == 'mockstarket' && scroll > 0) {

        if(scroll >= 1380) {

        }
    }


});